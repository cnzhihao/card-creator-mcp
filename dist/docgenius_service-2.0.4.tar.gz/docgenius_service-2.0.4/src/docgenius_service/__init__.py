"""
DocGenius Service - AI驱动的动态文档生成服务

一个将文本转换为设计精美图片的MCP服务。
"""

__version__ = "2.0.4" 